<?php
   include_once('db.php');



   $_name = $_POST ['name'];
   $_foodOrdered = $_POST ['food-ordered'];
?>